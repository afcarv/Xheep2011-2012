/**
 * stub class to run the application.
 * 
 * @author dfof
 *
 */
public class Main
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		Application app = new Application();
		app.run();
	}

}
