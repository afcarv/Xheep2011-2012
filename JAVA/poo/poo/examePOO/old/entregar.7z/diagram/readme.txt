abrir no papyrus
http://www.papyrusuml.org/scripts/home/publigen/content/templates/show.asp?P=114&L=EN&ITEMID=7