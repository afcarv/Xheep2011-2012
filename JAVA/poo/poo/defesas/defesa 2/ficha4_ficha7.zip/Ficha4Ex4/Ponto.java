package Ficha4Ex4;

class Ponto{
	double x=0,y=0;
	Ponto(){};
	Ponto(double a,double b){
		x=a;
		y=b;
	}
}
