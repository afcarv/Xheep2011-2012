
public class EmpregadoComissao extends Empregado {
	

	
	public boolean addDay(int day, int val)
	{
		
		return true;
	}
}
