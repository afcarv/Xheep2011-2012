<?php
$inq = array (
"1010"=>array("","1.1 simpatia","R","","","","",""),
"1020"=>array("","1.2 qualidade","R","","","","",""),
"1030"=>array("","1.3 tempoR","R","","","","",""),
"1040"=>array("","1.4 Prazos","R","","","","",""),
"1050"=>array("","1.5 preocupa","R","","","","",""),
"1060"=>array("","1.6 disponibilidade","R","","","","",""),
"1070"=>array("","1.7 apoio","R","","","","",""),
"1080"=>array("","1.8 condicoes","R","","","","",""),
"1090"=>array("","1.9 precos","R","","","","",""),


"2010"=>array("","2.1 simpatia2","R","","","","",""),
"2020"=>array("","2.2 qualidade2","R","","","","",""),
"2030"=>array("","2.3 solucoes2","R","","","","",""),
"2040"=>array("","2.4 responsa2","R","","","","",""),
"2050"=>array("","2.5 resposta2","R","","","","",""),
"2060"=>array("","2.6 satisf2","R","","","","",""),
"2070"=>array("","2.7 materiais2","R","","","","",""),

"4010"=>array("","2.1 informacao4","R","","","","",""),
"4020"=>array("","2.2 eficiencia4","R","","","","",""),

"5010"=>array("","2.1 posicao5","R","","","","",""),
"5020"=>array("","2.2 diversidade5","R","","","","",""),


"3010"=>array("","3.1 local3","C","SIM","","","",""),
"3020"=>array("","3.2 qualidade3","C","SIM","","","",""),
"3030"=>array("","3.3 atitude3","C","SIM","","","",""),
"3040"=>array("","3.4 confianca3","C","SIM","","","",""),
"3050"=>array("","3.5 prazo3","C","SIM","","","",""),
"3060"=>array("","3.6 Joomla","C","SIM","","","",""),
"3070"=>array("","3.7 Oracle","C","SIM","","","",""),

"6030"=>array("","6.3 Cabo","R","SIM","","","",""),


"9090"=>array("","9.9 OBSERVA��ES","O","4","","","","")
);

	$vinq = array();    // � muito importante para que os items seguintes fubcionem ....
?>

